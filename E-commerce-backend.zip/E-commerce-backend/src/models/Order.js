const orderSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
  total: Number,
  status: String,
  createdAt: { type: Date, default: Date.now }
});

orderSchema.index({ user: 1, createdAt: -1 }); // ESR rule

module.exports = mongoose.model("Order", orderSchema);
