const paymentSchema = new mongoose.Schema({
  orderId: mongoose.Schema.Types.ObjectId,
  stripePaymentIntent: String,
  status: String
});

module.exports = mongoose.model("Payment", paymentSchema);
