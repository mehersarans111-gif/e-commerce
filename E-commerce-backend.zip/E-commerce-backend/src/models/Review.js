const reviewSchema = new mongoose.Schema({
  product: { type: mongoose.Schema.Types.ObjectId, ref: "Product" },
  rating: Number,
  comment: String
});

module.exports = mongoose.model("Review", reviewSchema);
