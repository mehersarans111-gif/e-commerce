const productSchema = new mongoose.Schema({
  name: String,
  description: String,
  price: Number,
  category: String,
  stock: Number,
  images: [String]
});

productSchema.index({ name: "text", description: "text" });
productSchema.index({ category: 1, price: 1 }); // domain index

module.exports = mongoose.model("Product", productSchema);
