const paymentIntent = await stripe.paymentIntents.create({
  amount: total * 100,
  currency: "inr"
});
app.post(
  "/webhook",
  bodyParser.raw({ type: "application/json" }),
  (req, res) => {
    const sig = req.headers["stripe-signature"];
    const event = stripe.webhooks.constructEvent(
      req.body,
      sig,
      process.env.STRIPE_WEBHOOK_SECRET
    );
    // update payment status
  }
);
