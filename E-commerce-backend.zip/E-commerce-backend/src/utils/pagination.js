exports.cursorPaginate = async (model, query, cursor, limit = 10) => {
  if (cursor) query._id = { $gt: cursor };
  const data = await model.find(query).limit(limit + 1);
  return {
    data: data.slice(0, limit),
    nextCursor: data.length > limit ? data[limit]._id : null
  };
};
